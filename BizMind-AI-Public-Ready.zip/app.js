'use strict';

/* BizMind AI v2 — local-first, explainable, rule-based business dashboard.
   ไม่มีการส่งข้อมูลออกจากเครื่องและยังไม่ได้เชื่อมต่อโมเดล AI ภายนอก */
const STORAGE_KEY = 'bizmind-entries-v2';
const LEGACY_KEY = 'bizmind-entries-v1';
const $ = (id) => document.getElementById(id);
const THB = new Intl.NumberFormat('th-TH', { maximumFractionDigits: 2 });
const NUM = new Intl.NumberFormat('th-TH', { maximumFractionDigits: 0 });
const CATEGORY_COLORS = ['#69e4c1', '#a594fc', '#76c5f5', '#ffcb8b', '#fc94a7', '#6f8fae'];
const CATEGORIES = {
  income: ['ยอดขายสินค้า', 'ค่าบริการ', 'รายได้อื่น'],
  expense: ['ต้นทุนสินค้า', 'การตลาด', 'ขนส่ง', 'ค่าเช่า', 'สาธารณูปโภค', 'ค่าใช้จ่ายอื่น']
};

const state = { entries: [], currentPage: 'dashboard', period: '30', search: '', kindFilter: 'all', toastTimer: null };
const fmtMoney = (value) => '฿' + THB.format(value || 0);
const fmtSignedMoney = (value) => (value >= 0 ? '+' : '−') + fmtMoney(Math.abs(value));
const pad = (n) => String(n).padStart(2, '0');
const dateString = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const localDate = (value) => new Date(`${value}T12:00:00`);
const dayStart = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const monthLabel = (d) => d.toLocaleDateString('th-TH', { month: 'short' });
const fullMonthLabel = (d) => d.toLocaleDateString('th-TH', { month: 'long', year: 'numeric' });
const safeId = () => (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') ? globalThis.crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;

function parseEntry(raw) {
  if (!raw || !['income', 'expense'].includes(raw.kind) || typeof raw.description !== 'string') return null;
  const amount = Number(raw.amount);
  if (!Number.isFinite(amount) || amount <= 0 || amount > 999999999999) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw.date || '')) return null;
  const parsed = localDate(raw.date);
  if (Number.isNaN(parsed.getTime()) || dateString(parsed) !== raw.date) return null;
  return { id: String(raw.id || safeId()), kind: raw.kind, category: String(raw.category || (raw.kind === 'income' ? 'รายได้อื่น' : 'ค่าใช้จ่ายอื่น')).slice(0, 50), description: raw.description.slice(0, 90), amount, date: raw.date, sample: Boolean(raw.sample) };
}
function load() {
  let saved = null;
  let hasV2 = false;
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data !== null) { saved = JSON.parse(data); hasV2 = true; }
    else {
      const legacy = localStorage.getItem(LEGACY_KEY);
      if (legacy !== null) saved = JSON.parse(legacy);
    }
  } catch (error) { console.warn('Local data is unavailable:', error); }
  if (Array.isArray(saved)) {
    state.entries = saved.map(parseEntry).filter(Boolean);
    if (!hasV2) persist(); // preserve any previous v1 entries while migrating to v2
  } else if (!hasV2) {
    state.entries = sampleEntries();
    persist();
  }
}
function persist() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state.entries)); }
  catch (error) { console.warn('Could not save local data:', error); showToast('ไม่สามารถบันทึกถาวรในเบราว์เซอร์นี้ได้'); }
}
function sampleEntries() {
  const now = new Date();
  const incomeMonths = [14500, 17300, 15900, 20200, 22500, 25800];
  const expenseMonths = [8600, 10400, 9400, 12600, 14000, 15100];
  const samples = [];
  for (let i = 0; i < 6; i++) {
    const month = new Date(now.getFullYear(), now.getMonth() - 5 + i, 1);
    const latestAllowedDay = (month.getFullYear() === now.getFullYear() && month.getMonth() === now.getMonth()) ? now.getDate() : 28;
    const days = [3, 8, 14, 19, 24];
    const values = [Math.round(incomeMonths[i] * .4), Math.round(expenseMonths[i] * .68), Math.round(incomeMonths[i] * .34), Math.round(expenseMonths[i] * .32), Math.round(incomeMonths[i] * .26)];
    const labels = ['ขายสินค้าออนไลน์', 'ซื้อวัตถุดิบและสินค้า', 'ยอดขายหน้าร้าน', 'ค่าการตลาดและขนส่ง', 'ยอดขายลูกค้าประจำ'];
    const kinds = ['income', 'expense', 'income', 'expense', 'income'];
    const categories = ['ยอดขายสินค้า', 'ต้นทุนสินค้า', 'ยอดขายสินค้า', 'การตลาด', 'ยอดขายสินค้า'];
    for (let k = 0; k < 5; k++) {
      // ทำให้ข้อมูลตัวอย่างเดือนปัจจุบันไม่อยู่ในอนาคต
      const day = Math.min(days[k], latestAllowedDay);
      samples.push({ id: safeId(), kind: kinds[k], category: categories[k], description: labels[k] + ' (ตัวอย่าง)', amount: values[k], date: dateString(new Date(month.getFullYear(), month.getMonth(), day)), sample: true });
    }
  }
  return samples;
}
function sum(entries) {
  let income = 0, expense = 0;
  for (const entry of entries) { if (entry.kind === 'income') income += entry.amount; else expense += entry.amount; }
  return { income, expense, profit: income - expense, margin: income > 0 ? (income - expense) / income * 100 : null };
}
function periodEntries(days, offset = 0) {
  if (days === 'all') return state.entries;
  const today = dayStart(new Date());
  const end = new Date(today); end.setDate(today.getDate() - Number(days) * offset);
  const start = new Date(end); start.setDate(end.getDate() - Number(days) + 1);
  return state.entries.filter(e => { const d = localDate(e.date); return d >= start && d < new Date(end.getFullYear(), end.getMonth(), end.getDate() + 1); });
}
function monthlyData() {
  const now = new Date();
  return Array.from({ length: 6 }, (_, i) => {
    const dt = new Date(now.getFullYear(), now.getMonth() - 5 + i, 1);
    const month = dateString(dt).slice(0, 7);
    return { date: dt, key: month, ...sum(state.entries.filter(e => e.date.slice(0, 7) === month)) };
  });
}
function latestEntries() { return [...state.entries].sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id)); }
function getExpenseGroups(rows) {
  const groups = new Map();
  for (const e of rows) if (e.kind === 'expense') groups.set(e.category, (groups.get(e.category) || 0) + e.amount);
  let sorted = [...groups].sort((a, b) => b[1] - a[1]);
  if (sorted.length > 5) sorted = [...sorted.slice(0, 4), ['อื่น ๆ', sorted.slice(4).reduce((total, item) => total + item[1], 0)]];
  return sorted;
}
function setText(id, value) { $(id).textContent = value; }
function create(tag, className = '', text = '') {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== '') el.textContent = text;
  return el;
}
function svgUse(icon) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('class', 'icon');
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  use.setAttribute('href', `#i-${icon}`);
  svg.append(use);
  return svg;
}
function deltaBadge(id, value, prev, invert = false) {
  const el = $(id); el.className = 'metric-change';
  if (!Number.isFinite(prev) || prev === 0) { el.textContent = '— ยังไม่มีฐานเปรียบเทียบ'; return; }
  const pct = (value - prev) / Math.abs(prev) * 100;
  if (!Number.isFinite(pct)) { el.textContent = '—'; return; }
  const good = invert ? pct <= 0 : pct >= 0;
  el.classList.add(good ? 'positive' : 'negative');
  el.textContent = `${pct >= 0 ? '↗' : '↘'} ${Math.abs(pct).toFixed(1)}%`;
}
function renderKpis() {
  const current = sum(periodEntries(state.period));
  const prior = state.period === 'all' ? null : sum(periodEntries(state.period, 1));
  setText('metricRevenue', fmtMoney(current.income));
  setText('metricExpense', fmtMoney(current.expense));
  setText('metricProfit', fmtMoney(current.profit));
  setText('metricMargin', current.margin === null ? '—' : `${current.margin.toFixed(1)}%`);
  deltaBadge('deltaRevenue', current.income, prior?.income);
  deltaBadge('deltaExpense', current.expense, prior?.expense, true);
  deltaBadge('deltaProfit', current.profit, prior?.profit);
  setText('marginDetail', current.income ? (current.profit >= 0 ? 'กำไรจากยอดขายที่บันทึก' : 'ผลประกอบการขาดทุน') : 'ยังไม่มีข้อมูลรายรับ');
}
function renderTrend(elementId, points) {
  const host = $(elementId);
  const svgNS = 'http://www.w3.org/2000/svg';
  const make = (tag, attrs = {}, text = null) => { const e = document.createElementNS(svgNS, tag); Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, String(v))); if (text !== null) e.textContent = text; return e; };
  const svg = make('svg', { viewBox: '0 0 780 280', preserveAspectRatio: 'none', 'aria-hidden': 'true' });
  const W = 780, H = 280, L = 57, R = 16, T = 24, B = 41, chartW = W - L - R, chartH = H - T - B;
  const high = Math.max(1, ...points.flatMap(p => [p.income, p.expense]));
  const step = high <= 10 ? 5 : Math.pow(10, Math.floor(Math.log10(high)));
  const top = Math.ceil(high / step) * step * 1.12;
  const x = i => L + chartW * i / Math.max(1, points.length - 1);
  const y = n => T + chartH - chartH * n / top;
  const abbr = n => n >= 1000000 ? `${(n / 1000000).toFixed(1)}m` : n >= 1000 ? `${(n / 1000).toFixed(n >= 10000 ? 0 : 1)}k` : NUM.format(n);
  for (let k = 0; k <= 4; k++) {
    const yCoord = T + k * chartH / 4;
    svg.append(make('line', { x1: L, y1: yCoord, x2: W - R, y2: yCoord, class: 'grid-line' }));
    svg.append(make('text', { x: 4, y: yCoord + 4 }, abbr(top * (1 - k / 4))));
  }
  points.forEach((p, i) => svg.append(make('text', { x: x(i), y: H - 11, 'text-anchor': 'middle' }, monthLabel(p.date))));
  const defs = make('defs');
  for (const [key, from] of [['income', '#69e4c1'], ['expense', '#9f8cff']]) {
    const gid = `${elementId}-${key}-fill`;
    const grad = make('linearGradient', { id: gid, x1: '0', x2: '0', y1: '0', y2: '1' });
    grad.append(make('stop', { offset: '0%', 'stop-color': from, 'stop-opacity': '.22' }));
    grad.append(make('stop', { offset: '100%', 'stop-color': from, 'stop-opacity': '0' }));
    defs.append(grad);
  }
  svg.append(defs);
  for (const [key, stroke, css] of [['expense', '#9f8cff', 'line-expense'], ['income', '#69e4c1', 'line-revenue']]) {
    const coords = points.map((p, i) => [x(i), y(p[key])]);
    const curve = coords.map(([cx, cy], i) => {
      if (i === 0) return `M ${cx} ${cy}`;
      const [px, py] = coords[i - 1];
      const middle = (px + cx) / 2;
      return `C ${middle} ${py}, ${middle} ${cy}, ${cx} ${cy}`;
    }).join(' ');
    const fill = `${curve} L ${x(coords.length - 1)} ${T + chartH} L ${x(0)} ${T + chartH} Z`;
    svg.append(make('path', { d: fill, fill: `url(#${elementId}-${key}-fill)` }));
    svg.append(make('path', { d: curve, fill: 'none', stroke, 'stroke-width': 3, 'stroke-linejoin': 'round', class: css }));
    coords.forEach(([cx, cy], i) => {
      const circ = make('circle', { cx, cy, r: 5, fill: stroke, class: 'point' });
      circ.append(make('title', {}, `${fullMonthLabel(points[i].date)}: ${key === 'income' ? 'รายรับ' : 'ค่าใช้จ่าย'} ${fmtMoney(points[i][key])}`));
      svg.append(circ);
    });
  }
  host.replaceChildren(svg);
}
function renderDonut(points) {
  const sixMonths = points.flatMap(p => state.entries.filter(e => e.date.slice(0, 7) === p.key));
  const groups = getExpenseGroups(sixMonths);
  const total = groups.reduce((n, [, amount]) => n + amount, 0);
  setText('donutTotal', fmtMoney(total));
  let start = 0;
  const colors = groups.map(([, amount], i) => {
    const end = start + (total ? amount / total * 100 : 0);
    const segment = `${CATEGORY_COLORS[i % CATEGORY_COLORS.length]} ${start.toFixed(3)}% ${end.toFixed(3)}%`;
    start = end;
    return segment;
  });
  $('expenseDonut').style.background = total ? `conic-gradient(${colors.join(',')})` : '#26364d';
  const items = groups.map(([name, amount], i) => {
    const item = create('div', 'category-item');
    const left = create('div', 'category-item-label');
    const dot = create('span', 'category-swatch'); dot.style.background = CATEGORY_COLORS[i % CATEGORY_COLORS.length];
    left.append(dot, create('span', '', name));
    item.append(left, create('span', 'category-percent', `${Math.round(amount / total * 100)}%`));
    return item;
  });
  $('expenseLegend').replaceChildren(...(items.length ? items : [create('div', 'empty-state', 'ยังไม่มีข้อมูลค่าใช้จ่ายใน 6 เดือน')]));
}
function renderRecent() {
  const rows = latestEntries().slice(0, 6).map(e => {
    const tr = create('tr');
    const desc = create('td'); desc.append(create('div', 'row-description', e.description), create('div', 'row-sub', e.category));
    const date = create('td', '', localDate(e.date).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: '2-digit' }));
    const amount = create('td', `align-right ${e.kind === 'income' ? 'amount-plus' : 'amount-minus'}`, fmtSignedMoney(e.kind === 'income' ? e.amount : -e.amount));
    tr.append(desc, date, amount); return tr;
  });
  if (!rows.length) { const tr = create('tr'); const td = create('td', 'empty-state', 'ยังไม่มีรายการ กด “เพิ่มรายการ” เพื่อเริ่มต้น'); td.colSpan = 3; tr.append(td); rows.push(tr); }
  $('recentRows').replaceChildren(...rows);
}
function insightRecords() {
  const now = new Date();
  const sixKeys = new Set(monthlyData().map(m => m.key));
  const rows = state.entries.filter(e => sixKeys.has(e.date.slice(0, 7)));
  const stats = sum(rows);
  const insights = [];
  const push = (title, detail, severity = 'good', icon = 'sparkles', tag = 'OPPORTUNITY') => insights.push({ title, detail, severity, icon, tag });
  if (!rows.length) {
    push('เริ่มจากข้อมูลชุดแรก', 'เพิ่มรายรับและค่าใช้จ่าย หรือโหลดข้อมูลตัวอย่าง เพื่อให้ระบบวิเคราะห์แนวโน้มได้', 'warn', 'info', 'GET STARTED');
    return insights;
  }
  if (stats.income <= 0) {
    push('ยังไม่มีรายรับในช่วงที่วิเคราะห์', 'บันทึกยอดขายของ 6 เดือนล่าสุดเพื่อใช้ประเมินผลกำไรและอัตรากำไร', 'warn', 'wallet', 'DATA NEEDED');
  } else if (stats.profit < 0) {
    push('ค่าใช้จ่ายสูงกว่ารายรับ', `ขาดทุนสุทธิ ${fmtMoney(Math.abs(stats.profit))} ในช่วง 6 เดือน ควรตรวจสอบหมวดต้นทุนที่สูงที่สุดเป็นอันดับแรก`, 'danger', 'activity', 'HIGH PRIORITY');
  } else {
    push('ธุรกิจมีกำไรจากข้อมูลที่บันทึก', `กำไรสุทธิ ${fmtMoney(stats.profit)} หรือ ${stats.margin.toFixed(1)}% ของรายรับในช่วง 6 เดือน ควรติดตามว่าผลนี้สม่ำเสมอหรือไม่`, 'good', 'trending', 'PERFORMANCE');
  }
  if (stats.income > 0) {
    const ratio = stats.expense / stats.income * 100;
    if (ratio > 70) push('สัดส่วนต้นทุนค่อนข้างสูง', `ค่าใช้จ่ายคิดเป็น ${ratio.toFixed(1)}% ของรายรับ ลองทบทวนต้นทุนสินค้าหรือราคาขายก่อนเพิ่มงบการตลาด`, 'warn', 'target', 'COST ALERT');
    else push('ควบคุมค่าใช้จ่ายได้ตามเกณฑ์ตัวอย่าง', `ค่าใช้จ่ายคิดเป็น ${ratio.toFixed(1)}% ของรายรับ ซึ่งต่ำกว่าเกณฑ์แจ้งเตือน 70% ที่กำหนดไว้ในต้นแบบ`, 'good', 'check', 'COST CONTROL');
  }
  const expenseGroups = getExpenseGroups(rows);
  if (expenseGroups.length && stats.expense > 0) {
    const [category, amount] = expenseGroups[0];
    push('หมวดค่าใช้จ่ายที่ใหญ่ที่สุด', `“${category}” มีค่าใช้จ่าย ${fmtMoney(amount)} คิดเป็น ${(amount / stats.expense * 100).toFixed(1)}% ของค่าใช้จ่ายทั้งหมด ควรเริ่มวิเคราะห์จากหมวดนี้`, 'warn', 'receipt', 'SPENDING');
  }
  const months = monthlyData();
  const [older, recent] = months.slice(-3, -1); // เทียบ 2 เดือนที่จบแล้ว ไม่รวมเดือนปัจจุบันที่ยังไม่เต็มเดือน
  if (older.income > 0 && recent.income > 0) {
    const percent = (recent.income - older.income) / older.income * 100;
    const rising = percent >= 0;
    push(rising ? 'ยอดขายเดือนล่าสุดที่จบแล้วเติบโต' : 'ยอดขายเดือนล่าสุดที่จบแล้วลดลง', `รายรับเดือน${monthLabel(recent.date)} ${rising ? 'เพิ่มขึ้น' : 'ลดลง'} ${Math.abs(percent).toFixed(1)}% เทียบกับเดือน${monthLabel(older.date)} ควรตรวจสอบสาเหตุประกอบก่อนตัดสินใจ`, rising ? 'good' : 'warn', 'chart', 'MONTHLY TREND');
  }
  if (rows.length < 10) push('เพิ่มความต่อเนื่องของข้อมูล', 'ข้อมูลยังมีน้อย การบันทึกรายการอย่างสม่ำเสมอจะช่วยให้ข้อสรุปมีประโยชน์มากขึ้น', 'warn', 'info', 'DATA QUALITY');
  return insights.slice(0, 6);
}
function healthScore() {
  const keys = new Set(monthlyData().map(m => m.key));
  const rows = state.entries.filter(e => keys.has(e.date.slice(0, 7)));
  const s = sum(rows);
  if (!rows.length || !s.income) return { score: null, name: 'ข้อมูลยังไม่พอสำหรับประเมิน', description: 'เพิ่มข้อมูลรายรับและค่าใช้จ่าย เพื่อให้ระบบคำนวณคะแนนตามเกณฑ์ตัวอย่าง' };
  const share = s.profit / s.income;
  const score = Math.round(Math.max(0, Math.min(100, 35 + Math.max(-35, Math.min(35, share * 70)) + (rows.length >= 12 ? 10 : rows.length >= 5 ? 5 : 0) + (s.profit > 0 ? 12 : -12))));
  const name = score >= 75 ? 'ภาพรวมอยู่ในเกณฑ์ดี' : score >= 50 ? 'มีพื้นที่ให้พัฒนาต่อ' : 'ควรทบทวนต้นทุนและรายรับ';
  return { score, name, description: `คะแนนประเมินเบื้องต้นจากอัตรากำไรสุทธิ ${s.margin.toFixed(1)}% และจำนวนรายการที่บันทึกใน 6 เดือนล่าสุด (${NUM.format(rows.length)} รายการ)` };
}
function tipNode(entry) {
  const outer = create('div', 'tip-item');
  const symbol = create('div', `tip-icon ${entry.severity === 'good' ? '' : entry.severity}`); symbol.append(svgUse(entry.icon));
  const body = create('div', 'tip-text'); body.append(create('strong', '', entry.title), create('p', '', entry.detail));
  outer.append(symbol, body); return outer;
}
function renderInsights() {
  const all = insightRecords();
  $('dashboardTips').replaceChildren(...all.slice(0, 3).map(tipNode));
  $('allInsights').replaceChildren(...all.map(info => {
    const card = create('article', 'insight-card');
    const header = create('div', 'insight-card-top');
    const icon = create('div', `insight-card-icon ${info.severity === 'good' ? '' : info.severity}`); icon.append(svgUse(info.icon));
    header.append(icon, create('span', 'insight-card-label', info.tag));
    card.append(header, create('h4', '', info.title), create('p', '', info.detail));
    return card;
  }));
  const health = healthScore();
  $('healthScore').textContent = health.score === null ? '—' : health.score;
  $('healthTitle').textContent = health.name;
  $('healthDescription').textContent = health.description;
  $('scoreRing').style.background = `conic-gradient(#69e9c5 0 ${health.score || 0}%, #2c4560 ${health.score || 0}% 100%)`;
}
function renderAnalytics(points) {
  const rows = state.entries.filter(e => points.some(p => e.date.slice(0, 7) === p.key));
  const s = sum(rows);
  setText('analyticsRevenue', fmtMoney(s.income));
  setText('analyticsExpense', fmtMoney(s.expense));
  setText('analyticsProfit', fmtMoney(s.profit));
  renderTrend('analyticsChart', points);
  $('monthlyRows').replaceChildren(...points.slice().reverse().map(p => {
    const tr = create('tr');
    const cells = [fullMonthLabel(p.date), fmtMoney(p.income), fmtMoney(p.expense), fmtMoney(p.profit), p.margin === null ? '—' : `${p.margin.toFixed(1)}%`];
    for (let i = 0; i < cells.length; i++) tr.append(create('td', `${i ? 'align-right ' : ''}${i === 0 ? 'monthly-table-month' : ''}${i === 3 && p.profit >= 0 ? ' amount-plus' : ''}`, cells[i]));
    return tr;
  }));
}
function renderAllTransactions() {
  const sorted = latestEntries();
  const filtered = sorted.filter(e => (state.kindFilter === 'all' || e.kind === state.kindFilter) && `${e.description} ${e.category} ${e.date}`.toLocaleLowerCase('th-TH').includes(state.search));
  setText('transactionCount', NUM.format(sorted.length));
  setText('incomeCount', NUM.format(sorted.filter(e => e.kind === 'income').length));
  setText('expenseCount', NUM.format(sorted.filter(e => e.kind === 'expense').length));
  setText('resultCount', `แสดง ${NUM.format(filtered.length)} จาก ${NUM.format(sorted.length)} รายการ`);
  const nodes = filtered.map(e => {
    const tr = create('tr');
    const desc = create('td'); desc.append(create('div', 'row-description', e.description));
    const category = create('td', '', e.category);
    const date = create('td', '', localDate(e.date).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' }));
    const amount = create('td', `align-right ${e.kind === 'income' ? 'amount-plus' : 'amount-minus'}`, fmtSignedMoney(e.kind === 'income' ? e.amount : -e.amount));
    const action = create('td', 'align-right');
    const del = create('button', 'delete-button'); del.type = 'button'; del.title = `ลบรายการ ${e.description}`; del.setAttribute('aria-label', `ลบรายการ ${e.description}`); del.dataset.deleteId = e.id; del.append(svgUse('trash'));
    action.append(del); tr.append(desc, category, date, amount, action); return tr;
  });
  if (!nodes.length) { const tr = create('tr'); const td = create('td', 'empty-state', 'ไม่พบรายการตามตัวกรองนี้'); td.colSpan = 5; tr.append(td); nodes.push(tr); }
  $('allRows').replaceChildren(...nodes);
}
function renderMode() {
  const samples = state.entries.filter(e => e.sample).length;
  $('modeLabel').textContent = samples === 0 ? 'ข้อมูลส่วนตัว' : samples === state.entries.length ? 'โหมดข้อมูลตัวอย่าง' : 'ข้อมูลผสมตัวอย่าง';
}
function renderAll() {
  renderMode();
  renderKpis();
  const months = monthlyData();
  renderTrend('trendChart', months);
  renderDonut(months);
  renderRecent();
  renderInsights();
  renderAnalytics(months);
  renderAllTransactions();
}
function navigate(page) {
  if (!['dashboard', 'analytics', 'transactions', 'insights'].includes(page)) return;
  state.currentPage = page;
  document.querySelectorAll('.page-view').forEach(view => { view.hidden = view.id !== `page-${page}`; });
  document.querySelectorAll('.nav-link').forEach(link => {
    const active = link.dataset.page === page;
    link.classList.toggle('active', active);
    if (active) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current');
    const dot = link.querySelector('.nav-point');
    if (active && !dot) link.append(create('span', 'nav-point'));
    if (!active && dot) dot.remove();
  });
  setText('breadcrumb', { dashboard: 'ภาพรวมธุรกิจ', analytics: 'วิเคราะห์ข้อมูล', transactions: 'รายการธุรกรรม', insights: 'Smart Insights' }[page]);
  closeSidebar();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function openSidebar() { $('sidebar').classList.add('open'); $('sidebarBackdrop').classList.add('open'); $('mobileMenu').setAttribute('aria-expanded', 'true'); }
function closeSidebar() { $('sidebar').classList.remove('open'); $('sidebarBackdrop').classList.remove('open'); $('mobileMenu').setAttribute('aria-expanded', 'false'); }
let modalPreviouslyFocused = null;
function refreshCategoryOptions() {
  const kind = $('entryKind').value;
  $('entryCategory').replaceChildren(...CATEGORIES[kind].map(category => { const option = create('option', '', category); option.value = category; return option; }));
}
function openModal() {
  modalPreviouslyFocused = document.activeElement;
  $('entryForm').reset();
  $('formError').hidden = true;
  $('entryDate').value = dateString(new Date());
  refreshCategoryOptions();
  $('entryModal').hidden = false;
  document.body.style.overflow = 'hidden';
  $('entryDescription').focus();
}
function closeModal() {
  $('entryModal').hidden = true;
  document.body.style.overflow = '';
  if (modalPreviouslyFocused?.focus) modalPreviouslyFocused.focus();
}
function showToast(message) {
  const toast = $('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  if (state.toastTimer) clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}
function addEntry(event) {
  event.preventDefault();
  const amount = Number($('entryAmount').value);
  const description = $('entryDescription').value.trim();
  const date = $('entryDate').value;
  const category = $('entryCategory').value;
  const parsed = parseEntry({ id: safeId(), kind: $('entryKind').value, amount, description, date, category, sample: false });
  if (!parsed || !description || !category || dayStart(localDate(date)) > dayStart(new Date())) {
    $('formError').hidden = false;
    $('formError').textContent = 'กรุณากรอกข้อมูลให้ถูกต้อง (ไม่รองรับวันที่ในอนาคต)';
    return;
  }
  state.entries.push(parsed);
  persist(); renderAll(); closeModal(); showToast('บันทึกรายการใหม่เรียบร้อยแล้ว');
}
function removeEntry(id) {
  const selected = state.entries.find(e => e.id === id);
  if (!selected || !window.confirm(`ต้องการลบรายการ “${selected.description}” ใช่หรือไม่?`)) return;
  state.entries = state.entries.filter(e => e.id !== id);
  persist(); renderAll(); showToast('ลบรายการเรียบร้อยแล้ว');
}
function clearAll() {
  if (!state.entries.length) { showToast('ไม่มีข้อมูลที่ต้องล้าง'); return; }
  if (!window.confirm('ยืนยันลบข้อมูลทั้งหมดบนเบราว์เซอร์นี้? การดำเนินการนี้ย้อนกลับไม่ได้')) return;
  state.entries = [];
  persist(); renderAll(); showToast('ล้างข้อมูลทั้งหมดแล้ว');
}
function resetDemo() {
  if (state.entries.length && !window.confirm('แทนที่รายการปัจจุบันด้วยข้อมูลตัวอย่างทั้งหมด? ข้อมูลเดิมจะถูกลบ')) return;
  state.entries = sampleEntries();
  persist(); renderAll(); showToast('โหลดข้อมูลตัวอย่างเรียบร้อยแล้ว');
}
function exportCsv() {
  if (!state.entries.length) { showToast('ยังไม่มีข้อมูลสำหรับส่งออก'); return; }
  const header = ['วันที่', 'ประเภท', 'หมวดหมู่', 'รายละเอียด', 'จำนวนเงิน (บาท)', 'ข้อมูลตัวอย่าง'];
  const values = latestEntries().map(e => [e.date, e.kind === 'income' ? 'รายรับ' : 'ค่าใช้จ่าย', e.category, e.description, e.amount, e.sample ? 'ใช่' : 'ไม่ใช่']);
  const escapeField = v => { const text = String(v); const safe = /^[=+\-@\t\r]/.test(text) ? '\'' + text : text; return `"${safe.replaceAll('"', '""')}"`; };
  // ใส่ BOM เพื่อให้ Excel เปิดภาษาไทยใน CSV ได้ง่ายขึ้น
  const csv = '\ufeff' + [header, ...values].map(row => row.map(escapeField).join(',')).join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = `bizmind-transactions-${dateString(new Date())}.csv`;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast('ส่งออกไฟล์ CSV แล้ว');
}
function initialize() {
  $('yearLabel').textContent = new Date().getFullYear();
  $('todayLabel').textContent = new Date().toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' });
  $('periodSelect').value = state.period;
  load();
  renderAll();
  document.querySelectorAll('.nav-link').forEach(link => link.addEventListener('click', () => navigate(link.dataset.page)));
  document.querySelectorAll('[data-go]').forEach(link => link.addEventListener('click', () => navigate(link.dataset.go)));
  document.querySelectorAll('[data-add]').forEach(button => button.addEventListener('click', openModal));
  document.querySelectorAll('[data-export]').forEach(button => button.addEventListener('click', exportCsv));
  $('periodSelect').addEventListener('change', e => { state.period = e.target.value; renderKpis(); });
  $('searchInput').addEventListener('input', e => { state.search = e.target.value.toLocaleLowerCase('th-TH').trim(); renderAllTransactions(); });
  $('kindFilter').addEventListener('change', e => { state.kindFilter = e.target.value; renderAllTransactions(); });
  $('allRows').addEventListener('click', e => { const btn = e.target.closest('[data-delete-id]'); if (btn) removeEntry(btn.dataset.deleteId); });
  $('clearAll').addEventListener('click', clearAll);
  $('resetDemo').addEventListener('click', resetDemo);
  $('entryKind').addEventListener('change', refreshCategoryOptions);
  $('entryForm').addEventListener('submit', addEntry);
  $('cancelModal').addEventListener('click', closeModal);
  $('closeModal').addEventListener('click', closeModal);
  $('entryModal').addEventListener('click', e => { if (e.target === $('entryModal')) closeModal(); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { if (!$('entryModal').hidden) closeModal(); else closeSidebar(); }
    // Basic focus trap for modal
    if (e.key === 'Tab' && !$('entryModal').hidden) {
      const nodes = [...$('entryModal').querySelectorAll('button,input,select')].filter(n => !n.disabled);
      const first = nodes[0], last = nodes[nodes.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  $('mobileMenu').addEventListener('click', () => $('sidebar').classList.contains('open') ? closeSidebar() : openSidebar());
  $('sidebarBackdrop').addEventListener('click', closeSidebar);
}
document.addEventListener('DOMContentLoaded', initialize);
